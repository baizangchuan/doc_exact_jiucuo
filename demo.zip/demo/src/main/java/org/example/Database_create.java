package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Database_create {

    public static final String JDBC_URL = "jdbc:mysql://111.9.47.74:8922/emr_parser";
    public static final String DB_USER = "root";
    public static final String DB_PASSWORD = "Aliab12!2020";

    public static void main(String[] args) {

    }
}
